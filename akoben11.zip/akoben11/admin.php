<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="css/admin.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="icon" href="img/icone-serenatto.png" type="image/x-icon">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
  <title>Akoben - Admin</title>
</head>
<body>
<main>
  <section class="container-admin-banner">
    <img src="assets/img/logo.png" class="logo-admin" alt="logo-akoben">
    <h1>Admistração Akoben</h1>
  </section>
  <h2>Lista de indicações</h2>

  <section class="container-table">
    <table>
      <thead>
        <tr>
          <th>Título</th>
          <th>Categoria</th>
          <th>Descricão</th>
          <th>Valor</th>
          <th colspan="2">Ação</th>
        </tr>
      </thead>
      <tbody>
      <tr>
        <td>Bife</td>
        <td>Almoço</td>
        <td>Delicioso prato</td>
        <td>R$ 25.00</td>
        <td><a class="botao-editar" href="editar-produto.html">Editar</a></td>
        <td>
          <form>
            <input type="button" class="botao-excluir" value="Excluir">
          </form>
        </td>
        
      </tr>
      <tr>
        <td>Frango</td>
        <td>Almoço</td>
        <td>Delicioso prato</td>
        <td>R$ 25.00</td>
        <td><a class="botao-editar" href="editar-produto.html">Editar</a></td>
        <td>
          <form>
            <input type="button" class="botao-excluir" value="Excluir">
          </form>
        </td>
      </tr>
      <tr>
        <td>Café Gelado</td>
        <td>Café</td>
        <td>Delicioso prato</td>
        <td>R$ 25.00</td>
        <td><a class="botao-editar" href="editar-produto.html">Editar</a></td>
        <td>
          <form>
            <input type="button" class="botao-excluir" value="Excluir">
          </form>
        </td>
      </tr>
      </tbody>
    </table>
  <a class="botao-cadastrar" href="cadastrarsugestoes.php">Cadastrar produto</a>
  <form action="#" method="post">
    <input type="submit" class="botao-cadastrar" value="Baixar Relatório"/>
  </form>
  </section>
</main>
</body>
</html>