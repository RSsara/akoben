<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Akoben - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Impact
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/impact-bootstrap-business-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <section id="topbar" class="topbar d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="coletivo.akoben@gmail.com">coletivo.akoben@gmail.com</a></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="https://www.instagram.com/_akoben/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </section><!-- End Top Bar -->

  <header id="header" class="header d-flex align-items-center">

    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        
        <h1>Akoben<span>.</span></h1>
      </a>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="#hero">Início</a></li>
          <li><a href="#about">Sobre nós</a></li>
          <li><a href="#services">Ações</a></li>
          <li><a href="#portfolio">Indicações</a></li>
          <li><a href="#team">Integrantes</a></li>
          
          
          <li><a href="#contact">Entre em contato conosco</a></li>
        </ul>
      </nav><!-- .navbar -->

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero">
    <div class="container position-relative">
      <div class="row gy-5" data-aos="fade-in">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
          <h2>Conheça o Akoben! <span></span></h2>
          <p>Somos um coletivo ativista quanto a questão indígena e afro-brasileira.</p>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="loginusuario.php" class="btn-get-started">Login</a>
            <a href="cadastrar-usuario.php" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Cadastre-se</span></a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2">
          <img src="assets/img/logo.png" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="100">
        </div>
      </div>
    </div>

    <div class="icon-boxes position-relative">
      <div class="container position-relative">
        <div class="row gy-4 mt-5">

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-easel"></i></div>
              <h4 class="title"><a href="" class="stretched-link">Feito por alunos para alunos</a></h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-gem"></i></div>
              <h4 class="title"><a href="" class="stretched-link">Eventos de conscientização</a></h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-geo-alt"></i></div>
              <h4 class="title"><a href="" class="stretched-link">Instituto Federal de Guarulhos</a></h4>
            </div>
          </div><!--End Icon Box -->

          <div class="col-xl-3 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-command"></i></div>
              <h4 class="title"><a href="" class="stretched-link">Clube de leitura</a></h4>
            </div>
          </div><!--End Icon Box -->

        </div>
      </div>
    </div>

    </div>
  </section>
  <!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Sobre nós</h2>
          <p>Somos um coletivo negro do Instituto Federal de São Paulo Câmpus-Guarulhos. Temos o objetivo de compartilhar conhecimentos e experiências sobre as relações étnico-raciais, incentivando a luta antirracista. </p>
        </div>

        <div class="row gy-4">
          <div class="col-lg-6">
            <h3>Junte-se a nós no Coletivo Negro do Instituto Federal de São Paulo Câmpus-Guarulhos!</h3>
            <img src="assets/img/about.jpg" class="img-fluid rounded-4 mb-4" alt="">
            <p>
              Você está em busca de um espaço onde suas vozes e experiências importam? Um lugar onde você pode aprender e compartilhar conhecimentos sobre as complexas relações étnico-raciais que moldam nossa sociedade? Um local onde a luta contra o racismo é uma prioridade?
              
              Se a resposta for sim, convidamos você a se juntar a nós no Coletivo Negro do Instituto Federal de São Paulo Câmpus-Guarulhos!
              
              Somos um grupo apaixonado de estudantes dedicados a promover a conscientização, educação e ação antirracista em nosso campus. Nosso objetivo é criar um ambiente inclusivo e igualitário para todos, independentemente da sua origem étnica ou racial. Aqui, buscamos construir uma comunidade que valorize e celebre a diversidade, reconhecendo que a força do nosso coletivo está na multiplicidade de experiências e perspectivas.
              
              Ao ingressar em nosso coletivo, você terá a oportunidade de:
          
             <p> 1. Participar de discussões enriquecedoras sobre questões étnico-raciais, aprendendo e compartilhando conhecimentos.</p>
             <p> 2. Colaborar em projetos e iniciativas que promovem a igualdade racial em nosso campus e na sociedade em geral.</p>
             <p>3. Conectar-se com pessoas que compartilham seus valores e interesses, construindo amizades duradouras.</p>
             <p>4. Fazer a diferença através do ativismo antirracista, enquanto inspira outros a se unirem à causa.</p>
              
              Não importa qual seja o seu background ou experiência prévia; todos são bem-vindos em nosso coletivo. Juntos, podemos criar um ambiente mais inclusivo e justo para todos os estudantes do Instituto Federal de São Paulo Câmpus-Guarulhos.
              
              Então, venha fazer parte desta jornada de educação, empoderamento e transformação. Junte-se a nós no Coletivo Negro e ajude a moldar um futuro mais igualitário e antirracista. Entre em contato conosco hoje e faça parte dessa mudança!</p>
          </div>
          <div class="col-lg-6">
            <div class="content ps-0 ps-lg-5">
              <p class="fst-italic">
                O clube de leitura do nosso Coletivo Negro é uma verdadeira joia escondida!
              </p>
              <ul>
                <li><i class="bi bi-check-circle-fill"></i> Exploração Literária Afro-Brasileira: No nosso clube de leitura, mergulhamos nas obras de autores afro-brasileiros e de outras partes do mundo, explorando suas histórias, perspectivas e contribuições para a literatura. É uma oportunidade única para ampliar nossos horizontes literários e conhecer novos talentos.</li>
                <li><i class="bi bi-check-circle-fill"></i> Diálogo e Discussão Significativa: Cada encontro do clube é uma oportunidade para um diálogo profundo e reflexivo sobre os temas abordados nas obras. Compartilhamos nossas impressões, críticas e interpretações, enriquecendo nossa compreensão e estimulando nossa criatividade.</li>
                <li><i class="bi bi-check-circle-fill"></i> Comunidade e Empoderamento: O clube de leitura cria um espaço seguro e acolhedor para compartilharmos nossas experiências e desafios relacionados às questões étnico-raciais, à medida que exploramos essas temáticas nas obras. É um lugar onde nos fortalecemos como indivíduos e como coletivo, encontrando inspiração e apoio uns nos outros.</li>
              </ul>
              <p>
                O clube de leitura do nosso Coletivo Negro não é apenas sobre livros; é sobre construir conexões significativas, promover a conscientização e fortalecer nossa luta antirracista. Junte-se a nós e descubra como a leitura pode ser uma ferramenta poderosa para a mudança e o crescimento pessoal.
              </p>

              <div class="position-relative mt-4">
                <img src="assets/img/team/time.jpg" class="img-fluid rounded-4" alt="">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

          </div>

        </div>

      </div>
    </section><!-- End Stats Counter Section -->

    <!-- ======= Call To Action Section ======= -->
    <section id="call-to-action" class="call-to-action">
      <div class="container text-center" data-aos="zoom-out">
        <a href="https://www.youtube.com/watch?v=GguuWQT7AX8&ab_channel=EventosIFSP-CampusGuarulhos" class="glightbox play-btn"></a>
        <h3>Um chamado para a ação antirracista</h3>
        <p> O Coletivo Akoben é um grupo de estudos e ação no combate ao racismo criado no âmbito do IFSP - Câmpus Guarulhos. O objetivo da live será divulgar a proposta do coletivo e convidar novos membros a participarem das ações que consistem em: a)grupos de estudos sobre as relações étnico-racias; b) eventos de divulgação científica: pesquisas e debates sobre as relações étnico-raciais; e c) produção de conteúdo informativo para a página do coletivo no Instagram.</p>
        <a class="cta-btn" href="#">Voltar para o início</a>
      </div>
    </section><!-- End Call To Action Section -->

    <!-- ======= Our Services Section ======= -->
    <section id="services" class="services sections-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Nossas ações</h2>
          <p> No Coletivo Negro do Instituto Federal de São Paulo Câmpus-Guarulhos, não nos limitamos apenas às palavras; nós transformamos ideias em ações concretas. Nossa dedicação à promoção da igualdade racial e ao combate ao racismo se traduz em uma série de iniciativas impactantes:</p>
        </div>

        <div class="row gy-4" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-4 col-md-6">
            <div class="service-item  position-relative">
              <div class="icon">
                <i class="bi bi-activity"></i>
              </div>
              <h3>Projetos de conscientização</h3>
              <p> Desenvolvemos projetos que visam aumentar a conscientização sobre o racismo e suas ramificações na sociedade. Isso inclui campanhas de sensibilização, exposições e outras atividades que envolvem nossa comunidade acadêmica.
</p>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="bi bi-broadcast"></i>
              </div>
              <h3>Ativismo nas redes sociais</h3>
              <p>Utilizamos as redes sociais como plataforma para disseminar informações, compartilhar histórias e promover ações antirracistas. Estamos comprometidos em usar nossa presença online para criar mudanças significativas.</p>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="bi bi-easel"></i>
              </div>
              <h3>Clube de leitura</h3>
              <p>Como coletivo, propomos a comunidade estudantil um clube de leitura com as temáticas do coletivo</p>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="bi bi-bounding-box-circles"></i>
              </div>
              <h3>Apoio à comunidade</h3>
              <p>Estamos ativamente envolvidos em atividades que beneficiam comunidades vulneráveis, promovendo a igualdade de oportunidades e oferecendo suporte a iniciativas que promovem o bem-estar das pessoas negras.</p>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="bi bi-calendar4-week"></i>
              </div>
              <h3>Eventos Educativos</h3>
              <p> Organizamos palestras, workshops e debates que abordam questões étnico-raciais, trazendo especialistas e ativistas para compartilhar seus conhecimentos. Esses eventos fornecem informações valiosas e estimulam discussões significativas em nosso campus.</p>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="bi bi-chat-square-text"></i>
              </div>
              <h3>Parcerias e Colaborações</h3>
              <p>Colaboramos com outros grupos e instituições que compartilham nossos objetivos. Isso nos permite ampliar nosso impacto e unir forças na luta contra o racismo.</p>
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>
    </section><!-- End Our Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Comentários sobre o coletivo</h2>
          <p>Aqui está a opinião de alguns membros e estudantes do IFSP Guarulhos sobre o coletivo.</p>
        </div>

        <div class="slides-3 swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/testimonials/let.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Leticia Gomes</h3>
                      <h4>Estudante do IFSP GRU </h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    O coletivo akoben tem se mostrado de grande importância no acúmulo de aprendizados. Estou encontrando diversos pontos de reflexões graças às esplêndidas indicações de conteúdos.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/testimonials/rafa.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Rafaella </h3>
                      <h4>Estudante do IFSP GRU.</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                   É de suma importância a existência de um coletivo militante nas questões raciais que seja direcionado aos alunos. Tem sido uma iniciativa enriquecedora para os alunos.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/testimonials/lu.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Luana Gomes</h3>
                      <h4>Estudante do IFSP GRU</h4>
                      <div class="stars">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                      </div>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                     O coletivo promove discussões de extrema importância para a convivência saudável no campus, realizando rodas de conversa que agregam diversos conhecimentos para aqueles que as ouvem.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/testimonials/gabi.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Gabriela Regina</h3>
                      <h4>Estudante do IFSP GRU</h4>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                     Não conheço ainda o coletivo mas parece ter uma boa proposta.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/team/hugo.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>KiriHugo</h3>
                      <h4>Estudante do IFSP GRU e coordenador do Akoben</h4>
                  
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    Coletivos com temas afro-brasileiros e indígenas no Brasil são muito necessários para a evolução da questão racial no país, pois ainda precisamos nos aprofundar nessas questões e o Akoben nos dá liberdade de pesquisar bastante sobre assuntos diversificados que ampliam nosso repertório cultural e nossa visão abrangente referente aos nossos antepassados.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <div class="d-flex align-items-center">
                    <img src="assets/img/testimonials/gabi.jpg" class="testimonial-img flex-shrink-0" alt="">
                    <div>
                      <h3>Julio Andrade</h3>
                      <h4>Estudante do IFSP GRU</h4>
                    </div>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                     Não conheço ainda o coletivo mas parece ter uma boa proposta.
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio sections-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Indicações</h2>
          <p>Essas são algumas indicações feitas por nós S2</p>
        </div>

        <div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry" data-portfolio-sort="original-order" data-aos="fade-up" data-aos-delay="100">

          <div>
            <ul class="portfolio-flters">
              <li data-filter="*" class="filter-active">Tudo</li>
              <li data-filter=".filter-livros">Livros</li>
              <li data-filter=".filter-series">Séries</li>
              <li data-filter=".filter-filmes">Filmes</li>
              <li data-filter=".filter-documentarios">Documentários</li>
            </ul><!-- End Portfolio Filters -->
          </div>

          <div class="row gy-4 portfolio-container">

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/racismorecreativo.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/racismorecreativo.jpg" class="img-fluid" alt="capa do livro de Racismo recreativo com Adlison Moreira"></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Racismo recreativo, Adilson Moreira </a></h4>
                  <p>Esse foi o primeiro livro trabalhado no nosso clube de leitura. Trata a forma que o racismo por muitas vezes é levado como brincadeira não sendo conferido a ele toda a seriedade necessária.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/product-1.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/manual.jpg" class="img-fluid" alt="capa do livro Pequeno manual antirracista"></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Pequeno Manual Antirracista, Djamila Ribeiro</a></h4>
                  <p>"Pequeno Manual Antirracista" de Djamila Ribeiro é uma obra essencial que desmascara o racismo no contexto brasileiro, abordando desde suas formas explícitas até as estruturais. A autora oferece orientações práticas para combater o preconceito racial, incentivando os leitores a desempenhar um papel ativo na promoção da igualdade racial. Este livro representa uma contribuição valiosa para o diálogo sobre a questão racial no Brasil. </p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-filmes">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/branding-1.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/corra.jpg" class="img-fluid" alt="banner do filme corra"></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Corra</a></h4>
                  <p>
                    "Corra!" é um filme de 2017 dirigido por Jordan Peele, que segue a história de Chris Washington, um jovem afro-americano, enquanto visita a família de sua namorada branca. O que começa como um fim de semana aparentemente comum se transforma em um pesadelo quando Chris percebe comportamentos racistas e sinistros dos habitantes da propriedade. O filme combina horror, suspense e crítica social de maneira impactante, explorando questões de racismo e preconceito de forma provocativa. "Corra!" é notável por sua originalidade, oferecendo uma visão poderosa das tensões raciais na sociedade contemporânea.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/books-1.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/hibiscoroxo.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Hibisco Roxo, Chimamanda Ngozi Adichie</a></h4>
                  <p> O livro explora questões de identidade, raça, gênero e pertencimento, fornecendo uma perspectiva profunda sobre as complexidades da experiência de imigrantes africanos nos Estados Unidos e o impacto do racismo e preconceito. "Hibisco Roxo" é amplamente elogiado por sua narrativa cativante e sua exploração de temas sociais importantes.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/app-2.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/oolho.png" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">O OLho mais Azul, Toni Morison</a></h4>
                    <p> O romance explora temas complexos, como racismo, identidade, beleza e alienação social. Toni Morrison aborda de forma sensível e perspicaz as questões da opressão racial e a busca por autoestima em uma sociedade que perpetua padrões eurocêntricos de beleza. "O Olho Mais Azul" é uma obra poderosa e provocativa que desafia o leitor a refletir sobre as questões de raça e identidade, além de ser um marco na literatura afro-americana.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/product-2.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/porque.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Por que eu não converso sobre raça com pessoas brancas, Reni Eddo-Lodge</a></h4>
                  <p>Eddo-Lodge desafia a ideia de que o fardo da educação sobre o racismo deve recair sobre as pessoas racializadas e explora como as pessoas brancas podem se tornar mais conscientes das questões raciais e engajar-se de maneira construtiva. A autora examina a história, a política e as experiências pessoais para explicar como o racismo persiste e se manifesta em diversas áreas da sociedade.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/branding-2.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/PORUMFEMINISMO.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Por um feminismo Afro Latino Americano, Lélia Gonzalez</a></h4>
                  <p>
                  No livro "Por um Feminismo Afro-Latino-Americano," Lélia Gonzalez ressalta a opressão enfrentada por mulheres negras na América Latina, enfatizando a necessidade de um feminismo inclusivo e interseccional. Ela explora as experiências complexas dessas mulheres, destacando seu papel no ativismo e no pensamento feminista. O livro apela ao reconhecimento das vozes e lutas das mulheres afrodescendentes, promovendo a busca por igualdade que leve em consideração suas experiências únicas. É uma obra seminal na literatura feminista, contribuindo significativamente para a discussão da interseccionalidade de gênero e raça na América Latina.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-documentarios">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/books-2.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/baseadoo.jpeg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Baseado em fatos raciais</a></h4>
                  <p>Esse documentário explora a relação entre a população negra e a criminalização da maconha nos Estados Unidos. Ele destaca como a legalização da maconha em algumas regiões do país leva a uma profunda reflexão sobre o impacto que a proibição da planta teve e continua a ter na vida dessa comunidade. A produção examina como as políticas de proibição afetaram de forma desproporcional os afro-americanos, e como a mudança para a legalização está gerando discussões críticas sobre justiça social e reforma do sistema criminal.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/app-3.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/americanah.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Americanah, Chimamanda Ngozi Adichie</a></h4>
                  <p>O livro aborda temas de identidade e raça, destacando os desafios enfrentados por Ifemelu devido ao racismo nos EUA, enquanto explora o relacionamento com seu amor de juventude, Obinze. A obra oferece uma visão perspicaz da experiência de africanos e afrodescendentes na diáspora e é elogiada por sua narrativa envolvente e suas críticas sociais afiadas.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-livros">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/product-3.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/oodio.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">O ódio que você semeia, Angie Thomas</a></h4>
                  <p>O livro aborda questões complexas de racismo, brutalidade policial e desigualdade social, enquanto acompanha a jornada de Starr em busca de justiça e sua própria identidade. A narrativa destaca as tensões raciais, as lutas familiares e o papel dos protestos na busca por igualdade.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-filmes">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/branding-3.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/CidadedeDeus.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Cidade de Deus</a></h4>
                  <p>"Cidade de Deus" é um filme brasileiro de 2002 que narra a vida na violenta favela do Rio de Janeiro chamada Cidade de Deus ao longo de várias décadas. O filme segue a perspectiva do personagem Buscapé e aborda temas como violência, pobreza e tráfico de drogas. É elogiado por sua narrativa impactante e realista, atuações excepcionais e direção inovadora, tornando-se um marco no cinema brasileiro e internacional.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-xl-4 col-md-6 portfolio-item filter-series">
              <div class="portfolio-wrap">
                <a href="assets/img/portfolio/books-3.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="assets/img/portfolio/bloodandwater.jpg" class="img-fluid" alt=""></a>
                <div class="portfolio-info">
                  <h4><a href="portfolio-details.html" title="More Details">Blood and water</a></h4>
                  <p>"Blood & Water" é uma série sul-africana de drama adolescente, lançada em 2020 na plataforma Netflix. A trama gira em torno de Puleng Khumalo, uma jovem estudante que se transfere para uma escola de elite na Cidade do Cabo, onde suspeita que uma das alunas seja sua irmã que foi sequestrada quando ainda era um bebê. Enquanto tenta descobrir a verdade sobre o desaparecimento de sua irmã, Puleng mergulha no mundo de segredos e intrigas que cercam as famílias ricas e influentes da escola.</p>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

          </div><!-- End Portfolio Container -->

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Our Team Section ======= -->
    <section id="team" class="team">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>integrantes</h2>
          <p>Esses são integrantes do nosso coletivo Akoben</p>
        </div>

        <div class="row gy-4">

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <img src="assets/img/team/cris.jpg" class="img-fluid" alt="">
              <h4>Cistiane Santana </h4>
              <span>Professora de português do IFSP Guarulhos</span>
              <div class="social">
                <a href="https://www.instagram.com/crissantana25/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <img src="assets/img/team/ju.jpg" class="img-fluid" alt="">
              <h4>Juliana</h4>
              <span>Professora de Sociologia do IFSP Guarulhos</span>
              <div class="social">
                <a href=""><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <img src="assets/img/team/ana.jpg" class="img-fluid" alt="">
              <h4>Ana Beatriz</h4>
              <span>Estudante do IFSP Guarulhos e coordenadora do Akoben</span>
              <div class="social">
                <a href="https://www.instagram.com/ana.miaugoat/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="assets/img/team/sara.jpg" class="img-fluid" alt="">
              <h4>Sara Ribeiro</h4>
              <span>Estudante do IFSP Guarulhos e coordenadora do Akoben</span>
              <div class="social">
                <a href="https://www.instagram.com/_sararibeiros/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="assets/img/team/hugo2.jpg" class="img-fluid" alt="">
              <h4>KiriHugo</h4>
              <span>Estudante do IFSP Guarulhos e coordenador do Akoben</span>
              <div class="social">
                <a href="https://www.instagram.com/kiri.hugo/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="assets/img/team/weslayne.jpg" class="img-fluid" alt="">
              <h4>Weslayne Caldeira</h4>
              <span>Estudante do IFSP Guarulhos e coordenadora do Akoben</span>
              <div class="social">
                <a href="https://www.instagram.com/veslein/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div>


          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="assets/img/team/natanael.jpg" class="img-fluid" alt="">
              <h4>Natanael Feitosa</h4>
              <span>Estudante do IFSP Guarulhos e coordenador do Akoben</span>
              <div class="social">
                <a href="https://www.instagram.com/natanael_vf/"><i class="bi bi-instagram"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Our Team Section -->



    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">

          <div class="col-lg-4">
            <div class="content px-xl-5">
              <h3>Perguntas frequentes </h3>
              <p>Essas são algumas perguntas que recebemos.</p>
            </div>
          </div>

          <div class="col-lg-8">

            <div class="accordion accordion-flush" id="faqlist" data-aos="fade-up" data-aos-delay="100">

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                    <span class="num">1.</span>
                    O que significa a logo de vocês?
                  </button>
                </h3>
                <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                    <span class="num">2.</span>
                    Por que Akoben?
                  </button>
                </h3>
                <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                    <span class="num">3.</span>
                    Quem pode fazer parte?
                  </button>
                </h3>
                <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                  </div>
                </div>
              </div><!-- # Faq item-->

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->
      
    

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Entre em contato conosco</h2>
          <p>Envie-nos suas críticas, comentários e sugestões :)</p>
        </div>

        <div class="row gx-lg-0 gy-4">

          <div class="col-lg-4">

            <div class="info-container d-flex flex-column align-items-center justify-content-center">
              <div class="info-item d-flex">
                <i class="bi bi-geo-alt flex-shrink-0"></i>
                <div>
                  <h4>Localização:</h4>
                  <p>Avenida Salgado filho, 3501, Guarulhos, SP</p>
                </div>
              </div><!-- End Info Item -->

              <div class="info-item d-flex">
                <i class="bi bi-envelope flex-shrink-0"></i>
                <div>
                  <h4>Email:</h4>
                  <p>coletivo.akoben@gamil.com</p>
                </div>
              </div><!-- End Info Item -->

              <div class="info-item d-flex">
                <i class="bi bi-phone flex-shrink-0"></i>
                <div>
                  <h4>Instagram:</h4>
                  <p>coletivo_akoben</p>
                </div>
              </div><!-- End Info Item -->

              <div class="info-item d-flex">
                <i class="bi bi-clock flex-shrink-0"></i>
                <div>
                  <h4>Reunião:</h4>
                  <p>Segunda das 12:15 às 13:30</p>
                </div>
              </div><!-- End Info Item -->
            </div>

          </div>

          <div class="col-lg-8">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Seu nome" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Seu email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Assunto" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="7" placeholder="Mensagem" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Carregando</div>
                <div class="error-message"></div>
                <div class="sent-message">Sua mensagem foi enviada! Obrigado</div>
              </div>
              <div class="text-center"><button type="submit">Enviar mensagem</button></div>
            </form>
          </div><!-- End Contact Form -->

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-5 col-md-12 footer-info">
          <a href="index.php" class="logo d-flex align-items-center">
            <span>Akoben</span>
          </a>
          <p> Coletivo ativista de alunos e professores do Instituto Federal de Guarulhos.</p>
          <div class="social-links d-flex mt-4">
            <a href="https://www.instagram.com/_akoben/" class="instagram"><i class="bi bi-instagram"></i></a>
          </div>
        </div>

        <div class="col-lg-2 col-6 footer-links">
          <h4>Links úteis</h4>
          <ul>
            <li><a href="#">Início</a></li>
            <li><a href="#">Sobre nós</a></li>
            <li><a href="#">Ações</a></li>
          </ul>
        </div>

        <div class="col-lg-2 col-6 footer-links">
          <h4>Nossas ações</h4>
          <ul>
            <li><a href="#">Reuniões</a></li>
            <li><a href="#">Redes sociais</a></li>
            <li><a href="#">Clube de leitura</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
          <h4>Entre em contato conosco</h4>
          <p>
            Salgado filho <br>
            Guarulhos, SP 3501<br>
            Brasil<br><br>
            <strong>instagram</strong> coletivo_akoben <br>
            <strong>Email:</strong> coletivo.akoben@gmail.com<br>
          </p>

        </div>

      </div>
    </div>

    <div class="container mt-4">
      <div class="copyright">
        &copy; Copyright <strong><span>Akoben</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/impact-bootstrap-business-website-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>

  </footer><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
 
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

 
  
</body>

</html>