create database akoben;
use akoben; 
create table indicacoes (id int, nome varchar(30) , descricao varchar (1000), img varchar(100));
insert into indicacoes (id, nome, descricao, img) values
(7, 'Por um Feminismo Afro Latino Americano', 'Livro que explora as perspectivas e lutas das mulheres afro-latino-americanas no movimento feminista.', 'PORUMFEMINISMO.jpg'),
(10, 'Blood and Water', 'Série de TV que aborda questões de identidade racial e social na África do Sul.', 'bloodandwater.jpg'),
(6, 'Baseado em Fatos Reais', 'Documentário que analisa eventos históricos sob uma perspectiva racial e social.', 'baseadoo.jpeg'),
(4, 'O Olho Mais Azul', 'Livro de Toni Morrison que explora temas de raça e identidade em uma narrativa poderosa.', 'oolho.jpg'),
(12, 'Por que eu não converso mais sobre raça com pessoas brancas', 'Livro de Reni Eddo-Lodge que aborda questões de racismo e privilégio branco.', 'porque.jpg'),
(5, 'Hibisco Roxo', 'Livro de Chimamanda Ngozi Adichie que conta a história de uma mulher nigeriana em busca de identidade.', 'hibiscoroxo.jpg'),
(8, 'Americanah', 'Outro livro de Chimamanda Ngozi Adichie que explora a experiência de uma nigeriana nos EUA.', 'americanah.jpg'),
(2, 'Pequeno Manual Antirracista', 'Livro de Djamila Ribeiro que oferece insights e estratégias para combater o racismo.', 'manual.jpg'),
(3, 'Corra!', 'Filme que aborda questões de racismo em um suspense psicológico.', 'corra.jpg'),
(9, 'O Ódio que Você Semeia', 'Livro de Angie Thomas que segue a jornada de uma adolescente enfrentando questões raciais após testemunhar um tiroteio policial.', 'oodio.jpg'),
(11, 'Cidade de Deus', 'Filme brasileiro que retrata a vida em uma favela e as complexas questões sociais envolvidas.', 'CidadeDeDeus.jpg');
(1, 'Racismo Recreativo', 'Livro de Adilson Moreira que explora o racismo velado e suas manifestações na sociedade brasileira.', 'racismo_recreativo.jpg');

create table usuario (email varchar (100), senha varchar (100))

   
