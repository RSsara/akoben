create database akoben;
use akoben; 
create table livros (id int, nome varchar(30) , descricao varchar (1000), img varchar(100));